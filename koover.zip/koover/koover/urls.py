"""koover URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from core import views

urlpatterns = [
    path('', views.home, name="inicio"),
    path('nosotros/', views.nosotros, name="nosotros"),
    path('login/', views.inicio, name="login"),
    path('404/', views.error, name="error"),
    path('contacto/', views.contacto, name="contacto"),
    path('e-educadores/', views.eeducadores, name="eeducadores"),
    path('e-maestros/', views.emaestros, name="emaestros"),
    path('e-profesores/', views.eprofesores, name="eprofesores"),
    path('e-tutores/', views.etutores, name="etutores"),
    path('faq/', views.faq, name="faq"),
    path('perfil/', views.perfil, name="perfil"),
    path('registro/', views.reg, name="reg"),
    path('s-cadetes/', views.cadetes, name="cadetes"),
    path('s-guias/', views.guias, name="guias"),
    path('s-recreativos/', views.recreativos, name="recreativos"),
    path('t-enfermeros/', views.tenfermeros, name="tenferemeros"),
    path('t-acompaniantes/', views.tacompaniantes, name="tacompaniantes"),
    path('t-medicos/', views.tmedicos, name="tmedicos"),
    path('t-psicologos/', views.tpsicologos, name="tpsicologos"),
    path('admin/', admin.site.urls),
]
