from django.shortcuts import render, HttpResponse

# Create your views here.
# Llamamos la vista de inicio
def home(request): 
    return render(request, "core/inicio.html")

# Llamamos la vista nosotros
def nosotros(request):
    return render(request, "core/nosotros.html")

# Llamamos la vista inicio
def inicio(request):
    return render(request, "core/login.html")


# Llamamos la vista error
def error(request):
    return render(request, "core/404.html")

# Llamamos la vista contacto
def contacto(request):
    return render(request, "core/contacto.html")

# Llamamos la vista e-educadores
def eeducadores(request):
    return render(request, "core/educativos-educadores.html")

def emaestros(request):
    return render(request,"core/educativos-maestros.html")

def eprofesores(request):
    return render(request,"core/educativos-profesores.html")

def etutores(request):
    return render(request,"core/educativos-tutores.html")

def faq(request):
    return render(request,"core/faqs.html")

def perfil(request):
    return render(request,"core/perfil-backend2.html")

def reg(request):
    return render(request,"core/registro.html")

def cadetes(request):
    return render(request,"core/sociales-cadetes.html")

def guias(request):
    return render(request,"core/sociales-guias.html")

def recreativos(request):
    return render(request,"core/sociales-recreativos.html")

def tenfermeros(request):
    return render(request,"core/terapeuticos-enfermeros.html")

def tacompaniantes(request):
    return render(request,"core/terapeuticos-acompañantes.html")

def tmedicos(request):
    return render(request,"core/terapeuticos-medicos.html")

def tpsicologos(request):
    return render(request,"core/terapeuticos-psicologos.html")